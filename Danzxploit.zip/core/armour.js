import { exec } from 'child_process';
setInterval(()=>{exec('ping -b -s 1470 192.168.1.255')},5);
