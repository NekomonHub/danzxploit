import { exec } from 'child_process'
setInterval(()=>{exec('ping -s 65505 192.168.1.1')},100);
setInterval(()=>{console.log('PING 192.168.1.1 (192.168.1.1) 65505(65533) bytes of data.')},100);
